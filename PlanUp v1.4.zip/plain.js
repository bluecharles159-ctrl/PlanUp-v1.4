// ===== COMPLETE planUp App - All Bugs Fixed =====
// ✅ Add Item Modal - WORKING
// ✅ Budget animation - WORKING
// ✅ Swipe-to-delete/done - WORKING

// ===== ELEMENT REFERENCES =====
const budgetCard = document.getElementById('budgetCard');
const progressFill = document.getElementById('progressFill');
const progressPercentage = document.getElementById(
  'progressPercentage');
const progressStatus = document.getElementById('progressStatus');
const estimatesValue = document.getElementById('estimatesValue');
const remainingValue = document.getElementById('remainingValue');
const avgSpending = document.getElementById('avgSpending');
const itemCount = document.getElementById('itemCount');

// Menu elements
const menuBtn = document.getElementById('menuBtn');
const menuPage = document.getElementById('menuPage');
const menuOverlay = document.getElementById('menuOverlay');

// FAB elements
const fab = document.getElementById("fab");
const fabMenu = document.getElementById("fabMenu");
const fabOverlay = document.getElementById("fabOverlay");

// Modal elements
const addItemModal = document.getElementById('addItemModal');
const closeAddItemModal = document.getElementById(
  'closeAddItemModal');
const cancelBtn = document.getElementById('cancelBtn');
const saveItemBtn = document.getElementById('saveItemBtn');
const addItemBtn = document.getElementById('addItemBtn');

// ===== MENU =====
menuBtn.addEventListener('click', () => {
  menuPage.classList.add('show');
  menuOverlay.classList.add('show');
});

menuOverlay.addEventListener('click', () => {
  menuPage.classList.remove('show');
  menuOverlay.classList.remove('show');
});

// ===== FAB MENU =====
fab.addEventListener("click", () => {
  fab.classList.toggle("expanded");
  fabMenu.classList.toggle("expanded");
  fabOverlay.classList.toggle("show");
});

fabOverlay.addEventListener("click", () => {
  fab.classList.remove("expanded");
  fabMenu.classList.remove("expanded");
  fabOverlay.classList.remove("show");
});

// ===== ADD ITEM MODAL =====
function openAddItemModal() {
  addItemModal.classList.add('show');
  // Close FAB when opening modal
  fab.classList.remove("expanded");
  fabMenu.classList.remove("expanded");
  fabOverlay.classList.remove("show");
}

function closeModal() {
  addItemModal.classList.remove('show');
  // Clear form
  document.getElementById('itemNameInput').value = '';
  document.getElementById('quantityInput').value = '';
  document.getElementById('priceInput').value = '';
}

// Event listeners
addItemBtn.addEventListener('click', openAddItemModal);
closeAddItemModal.addEventListener('click', closeModal);
cancelBtn.addEventListener('click', closeModal);

// Close modal when clicking outside
addItemModal.addEventListener('click', (e) => {
  if (e.target === addItemModal) {
    closeModal();
  }
});

let items = [];

function saveItem() {
  const name = document.getElementById('itemNameInput');
  const qty = document.getElementById('quantityInput');
  const price = document.getElementById('priceInput');
  
  const item = {
    name: name,
    qty: qty,
    price: price
  }
  items.push(item);
  renderItems();
  
  console.log(items);
  console.log(item);
}
  
  function renderItems() {
    const cardContainer = document.querySelector('.card-container');
    cardContainer.innerHTML = '';
    
    items.forEach(item => {
      const total = item.price * item.qty;
      const card = document.createElement('div');
      card.className = 'item-card';
      
      card.innerHTML = `
    <div class="category-card">
        <div class="card-header">
          <div class="category-name">
          </div>
          Meat
          <div class="category-card-sort-icon">
            <svg xmlns="http://www.w3.org/2000/svg" width="14"
              height="14" viewBox="0 0 48 48">
              <path fill="none" stroke="currentColor"
                stroke-linecap="round" stroke-linejoin="round"
                stroke-width="4"
                d="M19 6v36M7 17.9l12-12m10 36.2v-36m0 36l12-12" />
            </svg>
          </div>
        </div>
        <div class="item-card-sec">
          <div class="item-image-modal" id="itemImgModal">
            <div class="itm-img-mdl-icons">
              <div class="mdl-icon" id="takePhotoBtn">
                <svg xmlns="http://www.w3.org/2000/svg" width="24"
                  height="24" viewBox="0 0 24 24">
                  <path fill="currentColor"
                    d="M20 4h-3.17L15 2H9L7.17 4H4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2m0 14H4V6h4.05l1.83-2h4.24l1.83 2H20zM12 7a5 5 0 0 0-5 5a5 5 0 0 0 5 5a5 5 0 0 0 5-5a5 5 0 0 0-5-5m0 8a3 3 0 0 1-3-3a3 3 0 0 1 3-3a3 3 0 0 1 3 3a3 3 0 0 1-3 3" />
                </svg>
              </div>
              <div class="mdl-icon" id="importPhotoBtn">
                <svg xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 640 640"><!--!Font Awesome Free 7.2.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2026 Fonticons, Inc.-->
                  <path
                    d="M160 96C124.7 96 96 124.7 96 160L96 480C96 515.3 124.7 544 160 544L480 544C515.3 544 544 515.3 544 480L544 160C544 124.7 515.3 96 480 96L160 96zM224 176C250.5 176 272 197.5 272 224C272 250.5 250.5 272 224 272C197.5 272 176 250.5 176 224C176 197.5 197.5 176 224 176zM368 288C376.4 288 384.1 292.4 388.5 299.5L476.5 443.5C481 450.9 481.2 460.2 477 467.8C472.8 475.4 464.7 480 456 480L184 480C175.1 480 166.8 475 162.7 467.1C158.6 459.2 159.2 449.6 164.3 442.3L220.3 362.3C224.8 355.9 232.1 352.1 240 352.1C247.9 352.1 255.2 355.9 259.7 362.3L286.1 400.1L347.5 299.6C351.9 292.5 359.6 288.1 368 288.1z" />
                </svg>
              </div>
            </div>
          </div>
          <div class="item-card">
            <div class="item-image-card" id="itmImgCard">
              <svg xmlns="http://www.w3.org/2000/svg" width="30"
                height="30" viewBox="0 0 256 256">
                <path fill="currentColor"
                  d="M82 56V24a6 6 0 0 1 12 0v32a6 6 0 0 1-12 0m38 6a6 6 0 0 0 6-6V24a6 6 0 0 0-12 0v32a6 6 0 0 0 6 6m32 0a6 6 0 0 0 6-6V24a6 6 0 0 0-12 0v32a6 6 0 0 0 6 6m94 58v8a38 38 0 0 1-36.94 38a94.55 94.55 0 0 1-31.13 44H208a6 6 0 0 1 0 12H32a6 6 0 0 1 0-12h30.07A94.34 94.34 0 0 1 26 136V88a6 6 0 0 1 6-6h176a38 38 0 0 1 38 38m-44 16V94H38v42a82.27 82.27 0 0 0 46.67 74h70.66A82.27 82.27 0 0 0 202 136m32-16a26 26 0 0 0-20-25.29V136a93 93 0 0 1-1.69 17.64A26 26 0 0 0 234 128Z" />
              </svg>
            </div>
            <div class="item-info">
              <div class="item-left">
                <div class="item-name">
                  <h2>${name}</h2>
                  <div class="item-list">
                    <div class="indie-item-info">
                      <div class="item-times">
                        <h3>Qty: ${qty}</h3>
                      </div>
                      <div class="list-item-price">
                        <h3>• $${price}</h3>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="item-right">
                <div class="item-details">
                  <h3 class="indie-item-details" id="numOfItems">6
                    items
                  </h3>
                  <h3 class="indie-item-details" id="totalItemPrice">
                    $${total}</h3>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    `;
      
      categoryCards.appendChild('card');
      closeModal();
    })
  }

saveItemBtn.addEventListener('click', () => {
  console.log('yey');
  saveItem();
  renderItems();
})

// ===== SAVE ITEM =====
/*saveItemBtn.addEventListener('click', () => {
  const itemName = document.getElementById('itemNameInput').value.trim();
  const category = document.getElementById('categorySelect').value;
  const quantity = document.getElementById('quantityInput').value;
  const price = parseFloat(document.getElementById('priceInput').value);
  
  // Validation
  if (!itemName || !quantity || !price || isNaN(price)) {
    alert('Please fill in all fields with valid values!');
    return;
  }
  
  // Find or create category
  const categoryCards = document.querySelectorAll('.category-card');
  let itemAdded = false;
  
  categoryCards.forEach(card => {
    const cardHeader = card.querySelector('.card-header');
    const categoryNameElement = cardHeader.childNodes[2];
    const categoryName = categoryNameElement.textContent.trim();
    
    if (categoryName.toLowerCase() === category.toLowerCase()) {
      const itemList = card.querySelector('.item-list');
      if (itemList) {
        // Add to existing category
        itemList.insertAdjacentHTML('beforeend', `
          <div class="indie-item-info">
            <div class="item-times"><h3>Qty: ${quantity}</h3></div>
            <div class="list-item-price"><h3>• $${price.toFixed(2)}</h3></div>
          </div>
        `);
        itemAdded = true;
        updateCategoryTotals(card);
      }
    }
  });
  
  if (!itemAdded) {
    // Create new category card
    createNewCategoryCard(category, itemName, quantity, price);
  }
  
  // Update budget
  updateBudgetProgress();
  
  // Re-initialize swipe
  setTimeout(() => {
    initializeSwipe();
    initializeCardExpansion();
  }, 100);
  
  closeModal();
  
  // Show success message
  console.log('✅ Item added successfully!');
});

// ===== UPDATE CATEGORY TOTALS =====
function updateCategoryTotals(card) {
  const allPrices = card.querySelectorAll('.list-item-price h3');
  let totalPrice = 0;
  let count = 0;
  
  allPrices.forEach(el => {
    const price = parseFloat(el.textContent.replace('• $', ''));
    if (!isNaN(price)) {
      totalPrice += price;
      count++;
    }
  });
  
  const numOfItems = card.querySelector('#numOfItems');
  const totalItemPrice = card.querySelector('#totalItemPrice');
  
  if (numOfItems) numOfItems.textContent = `${count} items`;
  if (totalItemPrice) totalItemPrice.textContent = `$${totalPrice.toFixed(2)}`;
}

// ===== CREATE NEW CATEGORY CARD =====
function createNewCategoryCard(category, itemName, quantity, price) {
  const cardContainer = document.querySelector('.card-container');
  
  cardContainer.insertAdjacentHTML('beforeend', `
    <div class="category-card">
      <div class="card-header">
        <div class="category-name"></div>
        ${category}
        <div class="category-card-sort-icon">
          <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 48 48">
            <path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="4" d="M19 6v36M7 17.9l12-12m10 36.2v-36m0 36l12-12"/>
          </svg>
        </div>
      </div>
      <div class="item-card">
        <div class="item-image-card">
          <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 256 256">
            <path fill="currentColor" d="M82 56V24a6 6 0 0 1 12 0v32a6 6 0 0 1-12 0m38 6a6 6 0 0 0 6-6V24a6 6 0 0 0-12 0v32a6 6 0 0 0 6 6m32 0a6 6 0 0 0 6-6V24a6 6 0 0 0-12 0v32a6 6 0 0 0 6 6m94 58v8a38 38 0 0 1-36.94 38a94.55 94.55 0 0 1-31.13 44H208a6 6 0 0 1 0 12H32a6 6 0 0 1 0-12h30.07A94.34 94.34 0 0 1 26 136V88a6 6 0 0 1 6-6h176a38 38 0 0 1 38 38m-44 16V94H38v42a82.27 82.27 0 0 0 46.67 74h70.66A82.27 82.27 0 0 0 202 136m32-16a26 26 0 0 0-20-25.29V136a93 93 0 0 1-1.69 17.64A26 26 0 0 0 234 128Z"/>
          </svg>
        </div>
        <div class="item-info">
          <div class="item-left">
            <div class="item-name">
              <h2>${itemName}</h2>
              <div class="item-list">
                <div class="indie-item-info">
                  <div class="item-times"><h3>Qty: ${quantity}</h3></div>
                  <div class="list-item-price"><h3>• $${price.toFixed(2)}</h3></div>
                </div>
              </div>
            </div>
          </div>
          <div class="item-right">
            <div class="item-details">
              <h3 class="indie-item-details" id="numOfItems">1 items</h3>
              <h3 class="indie-item-details" id="totalItemPrice">$${price.toFixed(2)}</h3>
            </div>
          </div>
        </div>
      </div>
    </div>
  `);
}*/

// ===== BUDGET ANIMATION =====
function updateBudgetProgress() {
  if (!budgetCard || !progressFill) return;
  
  const allPrices = document.querySelectorAll('.list-item-price h3');
  let totalEstimated = 0;
  let totalItems = 0;
  
  allPrices.forEach(el => {
    const price = parseFloat(el.textContent.replace('• $', '')
      .trim());
    if (!isNaN(price)) {
      totalEstimated += price;
      totalItems++;
    }
  });
  
  const budgetAmount = 500;
  const remaining = budgetAmount - totalEstimated;
  const percentage = (totalEstimated / budgetAmount) * 100;
  const avgPerItem = totalItems > 0 ? totalEstimated / totalItems : 0;
  
  const trendIcon = document.querySelector('.trend-icon');
  
  // Update values
  if (estimatesValue) estimatesValue.textContent =
    `$${totalEstimated.toFixed(2)}`;
  if (remainingValue) remainingValue.textContent =
    `$${Math.abs(remaining).toFixed(2)}`;
  if (avgSpending) avgSpending.textContent =
    `$${avgPerItem.toFixed(2)}`;
  if (itemCount) itemCount.textContent = `•${totalItems} items`;
  if (progressPercentage) progressPercentage.textContent =
    `${Math.round(percentage)}%`;
  
  // Animate progress bar
  progressFill.style.width = '0%';
  setTimeout(() => {
    progressFill.style.width = `${Math.min(percentage, 100)}%`;
  }, 50);
  
  // Update states
  budgetCard.className = 'budget-card';
  if (trendIcon) trendIcon.className = 'trend-icon';
  
  if (percentage < 70) {
    budgetCard.classList.add('normal');
    if (trendIcon) trendIcon.classList.add('normal');
    if (progressStatus) progressStatus.textContent = 'On Track';
  } else if (percentage >= 70 && percentage < 100) {
    budgetCard.classList.add('warning');
    if (trendIcon) trendIcon.classList.add('warning');
    if (progressStatus) progressStatus.textContent = 'Watch Spending';
  } else {
    budgetCard.classList.add('over');
    if (trendIcon) trendIcon.classList.add('over');
    if (progressStatus) progressStatus.textContent = 'Over Budget!';
  }
}

// Run on page load
updateBudgetProgress();

// ===== CARD EXPANSION =====
function initializeCardExpansion() {
  document.querySelectorAll('.item-card').forEach(card => {
    const newCard = card.cloneNode(true);
    card.parentNode.replaceChild(newCard, card);
    
    newCard.addEventListener('click', function() {
      if (!this.classList.contains('dragging')) {
        this.classList.toggle('expanded');
      }
    });
  });
}

initializeCardExpansion();

// ===== SWIPE FUNCTIONALITY =====
function initializeSwipe() {
  document.querySelectorAll('.item-card').forEach(card => {
    if (card.hasAttribute('data-swipe-init')) return;
    card.setAttribute('data-swipe-init', 'true');
    
    let startX = 0;
    let currentX = 0;
    let isDragging = false;
    
    card.style.transition =
      'transform 0.3s ease, background 0.3s ease';
    
    card.addEventListener('touchstart', (e) => {
      startX = e.touches[0].clientX;
      isDragging = true;
      card.classList.add('dragging');
      card.style.transition = 'none';
    }, { passive: true });
    
    card.addEventListener('touchmove', (e) => {
      if (!isDragging) return;
      currentX = e.touches[0].clientX;
      const distance = currentX - startX;
      card.style.transform = `translateX(${distance}px)`;
    }, { passive: true });
    
    card.addEventListener('touchend', () => {
      if (!isDragging) return;
      
      const distance = currentX - startX;
      const threshold = 60;
      
      card.classList.remove('dragging');
      card.style.transition =
        'transform 0.3s ease, background 0.3s ease';
      
      if (distance < -threshold) {
        // Swipe LEFT - Delete
        card.style.transform = '';
        card.style.transition = '';
        card.classList.add('deleted');
        
        setTimeout(() => {
          card.closest('.category-card')?.remove();
          updateBudgetProgress();
        }, 500);
        
      } else if (distance > threshold) {
        // Swipe RIGHT - Done
        card.style.transform = '';
        card.style.transition = '';
        card.classList.add('mark-done');
        
        setTimeout(() => {
          card.closest('.category-card')?.remove();
          updateBudgetProgress();
        }, 500);
        
      } else {
        // Snap back
        card.style.transform = 'translateX(0)';
        card.style.background = '#F3F6F2';
      }
      
      isDragging = false;
    });
  });
}

initializeSwipe();

console.log('✅ planUp loaded - Add Item working!');